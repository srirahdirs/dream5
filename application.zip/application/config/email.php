<?php
 
$config['protocol'] = 'ssmtp';
$config['smtp_host'] = 'ssl://ssmtp.googlemail.com';
$config['smtp_port'] = '465';
$config['smtp_user'] = 'no-reply@tandem.network';
$config['smtp_pass'] = 'Totem2018';
//$config['smtp_user'] = '8149606f854d9892a2123652b2a6f9af';
//$config['smtp_pass'] = 'b9c872b1c0fdcd81f73ef1b7eb3423c5';
$config['charset'] = 'iso-8859-1';
$config['mailtype'] = 'html';
$config['newline'] = "\r\n";
 
?>
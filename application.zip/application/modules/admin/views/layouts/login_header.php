<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
   
    <title>DREAM5 - ADMIN</title>

    <!-- Vendor css -->
    <link href="<?=  base_url(); ?>/assets/admin/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?=  base_url(); ?>/assets/admin/lib/Ionicons/css/ionicons.css" rel="stylesheet">

    <!-- Slim CSS -->
    <link rel="stylesheet" href="<?=  base_url(); ?>/assets/admin/css/slim.css">
    <link rel="stylesheet" href="<?=  base_url(); ?>/assets/admin/css/custom.css">

  </head>
  <body>